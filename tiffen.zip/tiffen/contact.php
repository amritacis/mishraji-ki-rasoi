<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden  bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. Contact</p>
                        <h2>Contact us</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pt-2 conatct">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="card card-span mb-3 shadow-lg">
                    <div class="card-body pt-4 pb-3 px-5">
                        <div class="d-flex mb-3">
                            <div class="into-icon">
                            <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="info-text">
                                <h5>California, United States</h5>
                                <p>Santa monica bullevard</p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <div class="into-icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="info-text">
                                <h5>00 (440) 9865 562</h5>
                                <p>24X7 Support Available</p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <div class="into-icon">
                                <i class="fa fa-home"></i>
                            </div>
                            <div class="info-text">
                                <h5>Mon to Fri 9am to 6 pm</h5>
                                <p>Opening Hours</p>
                            </div>
                        </div>
                        <div class="d-flex mb-3">
                            <div class="into-icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="info-text">
                                <h5>support@tiffin.com</h5>
                                <p>Send us your query anytime!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="card card-span mb-3 shadow-lg">
                    <div class="card-body py-3">
                    <h3 class="pb-4">Fill The Below Form To Contct Us:</h3>
                        <form action="" method="POST">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" placeholder="Your Name">
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" placeholder="Your Email">
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="numb" placeholder="numb">
                                        <label for="numb">Number</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="subject" placeholder="Subject">
                                        <label for="subject">Subject</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" id="message" style="height: 100px"></textarea>
                                        <label for="message">Message</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <a class="btn btn-danger banner-btn1 float-end" type="submit">Send Message</a>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
            
        <div class="row">
            <div class="col-md-12">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3558.6834031057483!2d75.75614591491477!3d26.881798067891935!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396db4f798006cbb%3A0x1ba3f77f1a1f2382!2sCoral%20IT%20Solutions!5e0!3m2!1sen!2sin!4v1643866244949!5m2!1sen!2sin" width="100%" height="350" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>   
    </div><!-- end of .container-->
</section>
<?php
include("footer.php");
?>