<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. Order</p>
                        <h2>Menus</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- menu -->
<section class="menus-list bg-holder pt-0">

    <!--/.bg-holder-->
   <!--/.bg-holder-->
   <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center mx-auto">
                <h5 class="main-title">Our Menu</h5>
            </div>
            <div class="col-md-12">
                <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-breakfast-tab" data-bs-toggle="pill" data-bs-target="#pills-breakfast" type="button" role="tab" aria-controls="pills-breakfast" aria-selected="true"><i class="fa fa-coffee fa-1x icon-menu"></i> All Menu</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-lunch-tab" data-bs-toggle="pill" data-bs-target="#pills-lunch" type="button" role="tab" aria-controls="pills-lunch" aria-selected="false"><i class="fa fa-hamburger fa-1x icon-menu"></i> Weekly Menu</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-dinner-tab" data-bs-toggle="pill" data-bs-target="#pills-dinner" type="button" role="tab" aria-controls="pills-dinner" aria-selected="false"><i class="fa fa-utensils fa-1x icon-menu"></i> Thali/Tiffin</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-weekend-tab" data-bs-toggle="pill" data-bs-target="#pills-weekend" type="button" role="tab" aria-controls="pills-weekend" aria-selected="false"><i class="fa fa-hamburger fa-1x icon-menu"></i> Weekend Menu</button>
                    </li>
                </ul>
                <div class="tab-content justify-content-center mt-5" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-breakfast" role="tabpanel" aria-labelledby="pills-breakfast-tab">
                        <div class="row">
                            <div class="col-md-4">
                            <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Curry</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/4.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>  Matar Paneer </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Matar Paneer Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/5.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>  Mix Veg </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Mix Veg Curry : 16 Oz</p>
                                        </div>
                                    </div>

                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/6.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Daal Tadka </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Daal Tadka: 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/7.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Chole  </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Chole Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/8.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rajma  </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Rajma Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Roti / Puri</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti / Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$3</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti / Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$5</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 4 pieces</span></p>
                                        </div>
                                    </div>

                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti / Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 6 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti / Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$7</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 10 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/13.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Masala Puri </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$14</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 10 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/14.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Plain Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$12</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 10 pieces</span></p>
                                        </div>
                                    </div>
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/1.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/2.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Parathas</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/9.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Plain Paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$5</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/10.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Aloo Paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>

                                   
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/1.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/2.png" alt=""></span>

                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="pills-lunch" role="tabpanel" aria-labelledby="pills-lunch-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Curry</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/4.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>  Matar Paneer </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Matar Paneer Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/5.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>  Mix Veg </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Mix Veg Curry : 16 Oz</p>
                                        </div>
                                    </div>

                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/6.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Daal Tadka </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Daal Tadka: 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/7.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Chole  </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Chole Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/8.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rajma  </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Rajma Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Breads</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/9.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Plain paratha </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$5</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 Pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/10.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Aloo paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 Pieces</span></p>
                                        </div>
                                    </div>

                                    <div class="menus  d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$2</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 Pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                        <img src="assets/img/menu/12.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rice</h3>
                                                </div>
                                                <!-- <div class="one-forth">
                                                    <span class="price">$29</span>
                                                </div> -->
                                            </div>
                                            <!-- <p><span>Soya</span>, <span>Potatoes</span>, <span>Rice</span>,
                                                <span>Tomatoe</span>
                                            </p> -->
                                        </div>
                                    </div>
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-dinner" role="tabpanel" aria-labelledby="pills-dinner-tab">
                        <div class="row">
                            
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Tiffin</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/3.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Tiffin / Thali</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$15 </span>
                                                </div>
                                            </div>
                                            <p><span>Rice + 2 Roti + 1 Paratha + Daal  +Raita + 1 curry ( anyone from Daily Menu) + Pickle </span></p>
                                            <p>Daal and Curry size- 8 Oz</p>
                                        </div>
                                    </div>
                                    
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                            <!-- <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Thali</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/gallery/sr2.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Tiffin</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$15 </span>
                                                </div>
                                            </div>
                                            <p><span>Rice + 2 Roti + 1 Paratha + Dal  +Raita + 1 curry ( anyone from Daily Menu) + Pickle </span></p>
                                            <p>Daal and Curry size- 8 Oz</p>
                                        </div>
                                    </div>
                                    
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-weekend" role="tabpanel" aria-labelledby="pills-weekend-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Combo</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/1.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Chole + Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$10</span>
                                                </div>
                                            </div>
                                            <p><span>Chole: 8 Oz</span>, <span>Puri: 5 Pieces</span></p>
                                        </div>
                                    </div>
                                 

                                   
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Combo</h3>
                                    </div>
                                   
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/2.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rajma  + Chawal</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Rajma: 8 Oz</span>, <span>Chawal: 16 Oz</span></p>
                                        </div>
                                    </div>

                                   
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

           
        </div>

    </div>
</section>
<?php
include("footer.php");
?>