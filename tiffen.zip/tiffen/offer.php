<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden  bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. Offer</p>
                        <h2>All Offer</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pt-2  pb-3 conatct">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <img src="assets/img/gallery/offer1.jpg" alt="" width="100%">
            </div>
            <div class="col-md-3">
                <img src="assets/img/gallery/offer1.jpg" alt="" width="100%">
            </div>
            <div class="col-md-3">
                <img src="assets/img/gallery/offer1.jpg" alt="" width="100%">
            </div>
            <div class="col-md-3">
                <img src="assets/img/gallery/offer1.jpg" alt="" width="100%">
            </div>

        </div>


    </div><!-- end of .container-->
</section>
<?php
include("footer.php");
?>