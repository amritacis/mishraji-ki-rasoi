  <!-- footer -->
  <section class="py-0 pt-4 bg-1000 footer">
      <div class="container">

          <div class="row">
              <div class="col-6 col-md-4 col-lg-3 col-xxl-3 mb-2">
                  <h5 class="lh-lg fw-bold text-white">Company </h5>
                  <ul class="list-unstyled mb-md-4 mb-lg-0">
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="about.php">About Us</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="contact.php">Contact Us</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="menus.php">Menus</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="offer.php">Offers</a></li>
                  </ul>
              </div>
              <div class="col-6 col-md-4 col-lg-3 col-xxl-2 mb-2">
                  <h5 class="lh-lg fw-bold text-white">Menu</h5>
                  <ul class="list-unstyled mb-md-4 mb-lg-0">
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="menus.php">All Menu</a>
                      </li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="menus.php">Weekly Menu</a>
                      </li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="menus.php">Thali</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="menus.php"> Weekend Menu</a></li>
                  </ul>
              </div>

              <div class="col-6 col-md-4 col-lg-3 col-xxl-2 mb-2">
                  <h5 class="lh-lg fw-bold text-white">Categories</h5>
                  <ul class="list-unstyled mb-md-4 mb-lg-0">
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="tiffin_order.php">Breakfast</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="tiffin_order.php">Lunch</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="tiffin_order.php">Dinner</a></li>
                      <li class="lh-lg"><a class="text-200 text-decoration-none" href="party_order.php">Party Order</a></li>
                  </ul>
              </div>
              <div class="col-12 col-md-8 col-lg-6 col-xxl-5">
                  <h5 class="lh-lg fw-bold text-500">SUBSCRIBE US</h5>
                 
                  <h3 class="text-500 my-4">Receive exclusive offers and <br>discounts in your mailbox</h3>
                  <div class="row input-group-icon mb-3">
                      <div class="col-auto">
                          <svg class="svg-inline--fa fa-envelope fa-w-16 input-box-icon text-500 ms-3" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="envelope" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg="">
                              <path fill="currentColor" d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z">
                              </path>
                          </svg>
                          <!-- <i class="fas fa-envelope input-box-icon text-500 ms-3"></i> Font Awesome fontawesome.com -->
                          <input class="form-control input-box bg-800 border-0" type="email" placeholder="Enter Email" aria-label="email">
                      </div>
                      <div class="col-auto"> <button class="btn banner-btn1" type="submit">Subscribe</button>
                      </div>
                  </div>
              </div>
          </div>
          <hr class="border border-800">
          <div class="row flex-center pb-1">
              <div class="col-md-12 order-0">
                  <p class="text-200 text-center text-md-start">All rights Reserved &copy; MishraJi Ki Rasoi, 2022 | Designed and Developed By: <a href="https://coralitsolution.com/"><img src="assets/img/gallery/coral-logo.png" alt="logo" width="140"></a></p>
              </div>
             
          </div>
      </div>
      <!-- end of .container-->
  </section>

  </main>





  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <!-- <script src="assets/js/bootstrap.min.js"></script> -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/owl.carousel.min.js"></script>
  <script>
      const myCarousel = document.getElementById('myCarousel')
      myCarousel.addEventListener('slid.bs.carousel', function() {
          const activeItem = this.querySelector(".active");
          document.querySelector(".testi-img img").src = activeItem.getAttribute("data-img");
          document.querySelector(".testi-img .circle").style.backgroundColor = activeItem.getAttribute("data-color");
      })
  </script>
  <script>
      $('#carousels').owlCarousel({
          loop: true,
          margin: 10,
          nav: true,
          navText: [
              "<i class='fa fa-caret-left'></i>",
              "<i class='fa fa-caret-right'></i>"
          ],
          autoplay: true,
          autoplayHoverPause: true,
          responsive: {
              0: {
                  items: 1
              },
              600: {
                  items: 3
              },
              1000: {
                  items: 4
              }
          }
      })
  </script>
  <script>
      jQuery("#carousel").owlCarousel({
          loop: true,
          autoplay: true,
          // rewind: true,
          /* use rewind if you don't want loop */
          margin: 20,

          // animateOut: 'fadeOut',
          // animateIn: 'fadeIn',

          responsiveClass: true,
          autoHeight: true,
          autoplayTimeout: 7000,
          smartSpeed: 800,
          nav: true,
          responsive: {
              0: {
                  items: 2
              },

              600: {
                  items: 2
              },

              1024: {
                  items: 4
              },

              1366: {
                  items: 4
              }
          }
      });
  </script>

  <script src="vendors/fontawesome/all.min.js"></script>

  </body>

  </html>