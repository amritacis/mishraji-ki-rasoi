<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden  bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. Order</p>
                        <h2>Party Order</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="pt-2 conatct">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
<img src="assets/img/gallery/party.jpg" alt="" class="img-fluid">
            </div>
            <div class="col-md-7">
                <div class="card card-span mb-3 shadow-lg p-3">
                    <div class="card-body p-3">
                    <h2 class="pb-4">Fill The Below Form To Order Food :</h2>
                        <form action="" method="POST">
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="name" name="name" placeholder="Your Name">
                                        <label for="name">Your Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control" id="email" name="email" placeholder="Your Email">
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="numb" name="numb" placeholder="number">
                                        <label for="numb">Number</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="number" class="form-control" id="guest" name="guest" placeholder="Guest">
                                        <label for="guest">Number Of Guest</label>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <input type="date" class="form-control" id="guest" name="guest" placeholder="Date">
                                        <!-- <label for="guest">Date</label> -->
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-floating">
                                        <select name="days" id="days" class="form-control">
                                            <option value="1">Type Of Party</option>
                                            <option value="2">Wedding</option>
                                            <option value="3">Birthday</option>
                                            <option value="4">Dinner</option>
                                        </select>
                                        <!-- <label for="days">No of Days Preferred in a week *</label> -->
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="form-floating">
                                        <input type="text" class="form-control" id="address" name="address" placeholder="address">
                                        <label for="address">Address</label>
                                    </div>
                                </div>
                                <!-- <div class="col-4">
                                    <label class="mb-2"><strong>Select Timing : </strong> </label>
                                    <div class="form-floating">
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="check1" name="option1" value="something" checked>
                                            <label class="form-check-label" for="check1">Breakfast</label>
                                        </div>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="check2" name="option2" value="something">
                                            <label class="form-check-label" for="check2">Lunch</label>
                                        </div>
                                        <div class="form-check">
                                            <input type="checkbox" class="form-check-input" id="check3" name="option3" value="something">
                                            <label class="form-check-label" for="check3">Dinner</label>
                                        </div>


                                    </div>
                                </div>
                                <div class="col-4">
                                    <label class="mb-2 "><strong>Select Type :</strong> </label>
                                    <div class="form-floating">


                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" id="radio1" name="optradio" value="option1" checked>Lunch Tiffin
                                            <label class="form-check-label" for="radio1"></label>
                                        </div>
                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" id="radio2" name="optradio" value="option2">Nutri-meal
                                            <label class="form-check-label" for="radio2"></label>
                                        </div>
                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" id="radio3" name="optradio" value="option3">Customized
                                            <label class="form-check-label" for="radio3"></label>
                                        </div>


                                    </div>
                                </div>
                                <div class="col-4">
                                    <label class="mb-2 "><strong>Delivery Mode :</strong> </label>
                                    <div class="form-floating">


                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" id="mode1" name="optradiomode" value="optionm1" checked>Delivery
                                            <label class="form-check-label" for="mode1"></label>
                                        </div>
                                        <div class="form-check">
                                            <input type="radio" class="form-check-input" id="mode2" name="optradiomode" value="optionm2">Pickup
                                            <label class="form-check-label" for="mode2"></label>
                                        </div>



                                    </div>
                                </div> -->
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control" placeholder="Leave a message here" id="instructions" name="instructions" style="height: 120px"></textarea>
                                        <label for="instructions">Instructions</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <a class="btn btn-danger banner-btn1 float-end" type="submit">Send Message</a>

                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div><!-- end of .container-->
</section>
<?php
include("footer.php");
?>