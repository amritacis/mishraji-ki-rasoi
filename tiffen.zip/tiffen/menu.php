<main class="main" id="top">
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top py-0" data-navbar-on-scroll="data-navbar-on-scroll">
                <div class="container">
                    <a class="navbar-brand d-inline-flex" href="index.php"><img class="d-inline-block" src="assets/img/gallery/logo.png" alt="logo" width="110"></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon">
                        </span></button>
                    <div class="collapse navbar-collapse my-2 pt-2 mt-lg-0" id="navbarSupportedContent">
                        <div class="mx-auto pt-3 pt-lg-0 d-block ">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">About Us</a>
                                </li>

                                <!-- <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Services</a>
                                    <ul class="dropdown-menu shadow-warning">
                                        <li><a class="dropdown-item" href="#">Link</a></li>
                                        <li><a class="dropdown-item" href="#">Another link</a></li>
                                        <li><a class="dropdown-item" href="#">A third link</a></li>
                                    </ul>
                                </li> -->
                                <li class="nav-item">
                                    <a class="nav-link" href="menus.php">Menu</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="catering.php">Catering</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="offer.php">Offers</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                        <div class="d-flex mt-4 mt-lg-0 ms-lg-auto ms-xl-0">

                            <a href="tiffin_order.php" class="btn btn-white shadow-warning text-warning" type="submit"><i
                                    class="fas fa-envelope me-2"></i>Book Tiffin</a>
                        </div>
                    </div>
                </div>
            </nav>
        </header>