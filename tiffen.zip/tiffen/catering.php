<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. Catering</p>
                        <h2>Catering</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="pb-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center mx-auto mb-1 mb-md-2">
                <h5 class="main-title">Catering Trays</h5>
                <p>The Calculated Number Of People Is Based On Multilpe Dishes</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="catering">
                    <div class="img-catering text-center"><img src="assets/img/gallery/cloche.png" alt=""></div>
                    <h4 class="text-center">Full Tray</h4>
                    <p>Serves 40 People</p>
                    <div class="cater-list">
                        <ul>
                            <li>Vagetables <span>$120</span></li>
                            <li>Daal <span>$100</span></li>
                            <li>Pakora <span>$120</span></li>
                            <li>Chaat <span>$160</span></li>
                            <li>Gobi Manchurian  <span>$160</span></li>
                            <li>Jeera Rice  <span>$80</span></li>
                            <li>Biryani With Raita  <span>$120</span></li>
                            <li>Mic Veg Manchurian  <span>$160</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="catering">
                    <div class="img-catering text-center"><img src="assets/img/gallery/cloche.png" alt=""></div>
                    <h4 class="text-center">Medium Tray</h4>
                    <p>Serves 30 People</p>
                    <div class="cater-list">
                        <ul>
                            <li>Vagetables <span>$90</span></li>
                            <li>Daal <span>$720</span></li>
                            <li>Pakora <span>$90</span></li>
                            <li>Chaat <span>$120</span></li>
                            <li>Gobi Manchurian  <span>$120</span></li>
                            <li>Jeera Rice  <span>$60</span></li>
                            <li>Biryani With Raita  <span>$90</span></li>
                            <li>Mic Veg Manchurian  <span>$120</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="catering">
                    <div class="img-catering text-center"><img src="assets/img/gallery/cloche.png" alt=""></div>
                    <h4 class="text-center">Half Tray</h4>
                    <p>Serves 20 People</p>
                    <div class="cater-list">
                        <ul>
                            <li>Vagetables <span>$60</span></li>
                            <li>Daal <span>$50</span></li>
                            <li>Pakora <span>$60</span></li>
                            <li>Chaat <span>$80</span></li>
                            <li>Gobi Manchurian  <span>$80</span></li>
                            <li>Jeera Rice  <span>$40</span></li>
                            <li>Biryani With Raita  <span>$60</span></li>
                            <li>Mic Veg Manchurian  <span>$80</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="catering">
                    <div class="img-catering text-center"><img src="assets/img/gallery/cloche.png" alt=""></div>
                    <h4 class="text-center">Quarter Tray</h4>
                    <p>Serves 10 People</p>
                    <div class="cater-list">
                        <ul>
                            <li>Vagetables <span>$40</span></li>
                            <li>Daal <span>$35</span></li>
                            <li>Pakora <span>$40</span></li>
                            <li>Chaat <span>$50</span></li>
                            <li>Gobi Manchurian  <span>$60</span></li>
                            <li>Jeera Rice  <span>$25</span></li>
                            <li>Biryani With Raita  <span>$40</span></li>
                            <li>Mic Veg Manchurian  <span>$50</span></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="catering">
                    <div class="img-catering text-center"><img src="assets/img/gallery/cloche.png" alt=""></div>
                    <h4 class="text-center">Breads</h4>
                    <!-- <p>Serves 10 People</p> -->
                    <div class="cater-list">
                        <ul>
                            <li>10 Roti <span>$7</span></li>
                            <li>Plain Puri <span>$12</span></li>
                            <li>Masala Puri <span>$14</span></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<?php include("footer.php") ?>