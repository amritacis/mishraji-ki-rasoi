<div class="icon-bar">
    <a href="#" class="facebook"><i class="fab fa-facebook-f"></i></a>
    <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
    <a href="#" class="instagram"><i class="fab fa-instagram"></i></a>
    <a href="#" class="linkedin"><i class="fab fa-linkedin"></i></a>
    <a href="#" class="youtube"><i class="fab fa-youtube"></i></a>
</div>

<div class="social-buttonss">
    <a class="whatsapp" id="watspp_icon" title="Send Message on whatsapp using your phone" href="https://api.whatsapp.com/send?phone=+919694270187"><i class="fab fa-whatsapp" aria-hidden="true"></i></a>
</div>


<section class="overflow-hidden bg-banner" id="home">
    <div id="demo" class="carousel slide" data-bs-ride="carousel">

        <!-- Indicators/dots -->


        <!-- The slideshow/carousel -->
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="assets/img/gallery/b3.jpg" alt="Los Angeles" class="d-block" style="width:100%">

            </div>
            <div class="carousel-item">
                <img src="assets/img/gallery/b2.jpg" alt="Chicago" class="d-block" style="width:100%">

            </div>

        </div>

        <!-- Left and right controls/icons -->
        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
    <div class="container">
        <div class="row flex-center">
            <div class="col-md-5 col-lg-6 order-0 order-md-1 mt-4">
                <a class="img-landing-banner" href="#!"><img class="img-fluid" src="assets/img/gallery/banner1.png" alt="hero-header" /></a>
            </div>
            <div class="col-md-7 col-lg-6 bn-p-t pb-3 text-md-start text-center">
                <h1 class="display-2 text-light">Are you starving?</h1>
                <h1 class="text-800 bnr-dscrp-txt fs-3">Within a few clicks, find Home made food that<br class="d-none d-xxl-block" />are accessible near you.</h1>
                <div class="cards w-xxl-75">
                    <div class="gap-3 col-sm-auto">
                        <a class="btn btn-danger banner-btn1 mr-4" type="submit" href="tiffin_order.php">Book Tiffin</a>
                        <a class="btn btn-danger banner-btn2" type="submit" href="party_order.php">Party Order</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ============================================-->
<!-- <section> begin ============================-->
<section class="bg-primary-gradient pb-5">
    <div class="container how-starts">
        <div class="row justify-content-center g-0">
            <div class="col-xl-10">
                <div class="col-lg-6 text-center mx-auto mb-3 mb-md-5">
                    <h5 class="main-title">How does it work</h5>
                </div>
                <div class="row">
                    <div class="col-6 col-sm-6 col-md-3 mb-6">
                        <div class="text-center"><img class="shadow-icon" src="assets/img/gallery/location.png" height="112" alt="..." />
                            <h5 class="mt-4 fw-bold">Select location</h5>
                            <p class="mb-md-0">Choose the location where your food will be delivered.</p>
                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-3 mb-6">
                        <div class="text-center"><img class="shadow-icon" src="assets/img/gallery/order.png" height="112" alt="..." />
                            <h5 class="mt-4 fw-bold">Choose Meal</h5>
                            <p class="mb-md-0">Check over hundreds of menus to pick your favorite food</p>
                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-3 mb-6">
                        <div class="text-center"><img class="shadow-icon" src="assets/img/gallery/pay.png" height="112" alt="..." />
                            <h5 class="mt-4 fw-bold">Pay advanced</h5>
                            <p class="mb-md-0">It's quick, safe, and simple. Select several methods of payment
                            </p>
                        </div>
                    </div>
                    <div class="col-6 col-sm-6 col-md-3 mb-6">
                        <div class="text-center"><img class="shadow-icon" src="assets/img/gallery/meals.png" height="112" alt="..." />
                            <h5 class="mt-4 fw-bold">Enjoy meals</h5>
                            <p class="mb-md-0">Food is made and delivered directly to your home.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end of .container-->
</section>
<!-- <section> close ============================-->
<!-- ============================================-->

<section class="welcome-area section-padding2 py-2">
    <div class="container">
        <div class="row">
            <div class="col-md-5 align-self-center">
                <div class="welcome-img">
                    <img src="assets/img/gallery/about1.jpg" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-md-7 align-self-center">
                <div class="welcome-text mt-md-0">
                    <h5 class="main-titles">Welcome to MishraJi Ki Rasoi</h5>
                    <p class="pt-3">We are reviving the culture of homemade food by offering a variety of traditional dishes to the people. Mishra Ji Ki Rasoi is enabling localized home food experiences by providing a delicious variety of authentic dishes cooked by talented home chefs. The home chef has learned the art of cooking through his unwavering passion and trained by his mother and grandmother to infuse love into the food. Mishra Ji Ki Rasoi is very selective and responsible in selecting Home Chefs. As a Company Policy, our Chef Enrollment team visits every aspiring Home chef to check for Kitchen hygiene and cleanliness, Food Quality and Packaging standards. Our Team of Food Tasting Experts Upholds our unwavering Customer Promise to serve Delicious and Healthy Food. </p>
                    
                    <a href="about.php" class="btn btn-danger banner-btn1 mr-4" type="submit">See More</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- categories -->

<section class="py-0 categories">
    <div class="container">
        <div class="row h-100 gx-2 mt-2">
            <div class="col-lg-12 text-center mx-auto mb-1 mb-md-2">
                <h5 class="main-title">Our Best Popular Categories</h5>
            </div>
            <div class="col-sm-6 col-lg-3 col-6 mb-3 mb-md-0 h-100 pb-4">
                <div class="card card-span h-100">
                    <div class="position-relative"> <img class="img-fluid rounded-3 w-100" src="assets/img/gallery/sr1.jpg" alt="...">
                        <div class="card-actions">
                            <div class="badge badge-tiffin bg-primary px-4 pt-3 pb-3">
                                <div class="d-flex flex-between-center">
                                    <div class="text-white fs-4">Breakfast </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-6 mb-3 mb-md-0 h-100 pb-4">
                <div class="card card-span h-100">
                    <div class="position-relative"> <img class="img-fluid rounded-3 w-100" src="assets/img/gallery/sr2.jpg" alt="...">
                        <div class="card-actions">
                            <div class="badge badge-tiffin bg-primary px-4 pt-3 pb-3">
                                <div class="d-flex flex-between-center">
                                    <div class="text-white fs-4">Lunch</div>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-6 mb-3 mb-md-0 h-100 pb-4">
                <div class="card card-span h-100">
                    <div class="position-relative"> <img class="img-fluid rounded-3 w-100" src="assets/img/gallery/sr3.jpg" alt="...">
                        <div class="card-actions">
                            <div class="badge badge-tiffin bg-primary px-4 pt-3 pb-3">
                                <div class="d-flex flex-between-center">
                                    <div class="text-white fs-4">Dinner</div>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <div class="col-sm-6 col-lg-3 col-6 mb-3 mb-md-0 h-100 pb-4">
                <div class="card card-span h-100">
                    <div class="position-relative"> <img class="img-fluid rounded-3 w-100" src="assets/img/gallery/sr4.jpg" alt="...">
                        <div class="card-actions">
                            <div class="badge badge-tiffin bg-primary px-4 pt-3 pb-3">
                                <div class="d-flex flex-between-center">
                                    <div class="text-white fs-4"> <a href="party_order.php" class="text-white text-decoration-none"> Party Order</a></div>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <!-- end of .container-->
</section>

<!-- menu -->
<section class="menus-list bg-holder">

    <!--/.bg-holder-->
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center mx-auto">
                <h5 class="main-title">Our Menu</h5>
            </div>
            <div class="col-md-12">
                <ul class="nav nav-pills mb-3 justify-content-center" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-breakfast-tab" data-bs-toggle="pill" data-bs-target="#pills-breakfast" type="button" role="tab" aria-controls="pills-breakfast" aria-selected="true"><i class="fa fa-coffee fa-1x icon-menu"></i> All Menu</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-lunch-tab" data-bs-toggle="pill" data-bs-target="#pills-lunch" type="button" role="tab" aria-controls="pills-lunch" aria-selected="false"><i class="fa fa-hamburger fa-1x icon-menu"></i> Weekly Menu</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-dinner-tab" data-bs-toggle="pill" data-bs-target="#pills-dinner" type="button" role="tab" aria-controls="pills-dinner" aria-selected="false"><i class="fa fa-utensils fa-1x icon-menu"></i> Thali/Tiffin</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-weekend-tab" data-bs-toggle="pill" data-bs-target="#pills-weekend" type="button" role="tab" aria-controls="pills-weekend" aria-selected="false"><i class="fa fa-hamburger fa-1x icon-menu"></i> Weekend Menu</button>
                    </li>
                </ul>
                <div class="tab-content justify-content-center mt-5" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-breakfast" role="tabpanel" aria-labelledby="pills-breakfast-tab">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Curry</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/4.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Matar Paneer </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Matar Paneer Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/5.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Mix Veg </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Mix Veg Curry : 16 Oz</p>
                                        </div>
                                    </div>

                                    <!-- <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/6.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Daal Tadka </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Daal Tadka: 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/7.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Chole </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Chole Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/8.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rajma </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Rajma Curry : 16 Oz</p>
                                        </div>
                                    </div> -->
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Roti / Puri</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/11.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Roti / Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$3</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>

                                    <div class="menus border-bottom-0 d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/14.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Plain Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$12</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 10 pieces</span></p>
                                        </div>
                                    </div>
                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/1.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/2.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Parathas</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/9.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Plain Paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$5</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/10.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Aloo Paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 pieces</span></p>
                                        </div>
                                    </div>


                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/1.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/2.png" alt=""></span>

                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="tab-pane fade" id="pills-lunch" role="tabpanel" aria-labelledby="pills-lunch-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Curry</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/4.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Matar Paneer </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Matar Paneer Curry : 16 Oz</p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/5.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Mix Veg </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Mix Veg Curry : 16 Oz</p>
                                        </div>
                                    </div>

                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Breads</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/9.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Plain paratha </h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$5</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 Pieces</span></p>
                                        </div>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/10.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3> Aloo paratha</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$6</span>
                                                </div>
                                            </div>
                                            <p><span>Quantity: 2 Pieces</span></p>
                                        </div>
                                    </div>

                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/3.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/4.png" alt=""></span>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-dinner" role="tabpanel" aria-labelledby="pills-dinner-tab">
                        <div class="row">

                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Tiffin</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/3.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Tiffin</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$15 </span>
                                                </div>
                                            </div>
                                            <p><span>Rice + 2 Roti + 1 Paratha + Daal +Raita + 1 curry ( anyone from Daily Menu) + Pickle </span></p>
                                            <p>Daal and Curry size- 8 Oz</p>
                                        </div>
                                    </div>

                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                            <!-- <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Thali</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/gallery/sr2.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Tiffin</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$15 </span>
                                                </div>
                                            </div>
                                            <p><span>Rice + 2 Roti + 1 Paratha + Dal  +Raita + 1 curry ( anyone from Daily Menu) + Pickle </span></p>
                                            <p>Daal and Curry size- 8 Oz</p>
                                        </div>
                                    </div>

                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div> -->
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-weekend" role="tabpanel" aria-labelledby="pills-weekend-tab">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Combo</h3>
                                    </div>
                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/1.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Chole + Puri</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$10</span>
                                                </div>
                                            </div>
                                            <p><span>Chole: 8 Oz</span>, <span>Puri: 5 Pieces</span></p>
                                        </div>
                                    </div>



                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="menu-wrap">
                                    <div class="heading-menu text-center ftco-animate fadeInUp ftco-animated">
                                        <h3>Combo</h3>
                                    </div>

                                    <div class="menus d-flex ftco-animate fadeInUp ftco-animated">
                                        <div class="menu-img">
                                            <img src="assets/img/menu/2.jpg" alt="" class="img-fluid">
                                        </div>
                                        <div class="text">
                                            <div class="d-flex">
                                                <div class="one-half">
                                                    <h3>Rajma + Chawal</h3>
                                                </div>
                                                <div class="one-forth">
                                                    <span class="price">$8</span>
                                                </div>
                                            </div>
                                            <p><span>Rajma: 8 Oz</span>, <span>Chawal: 16 Oz</span></p>
                                        </div>
                                    </div>


                                    <span class="flat" style="left: 0;"> <img src="assets/img/gallery/5.png" alt=""></span>
                                    <span class="flats" style="right: 0;"> <img src="assets/img/gallery/6.png" alt=""></span>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-12">

                <div class="text-center mb-3">
                    <a class="btn btn-danger banner-btn2" type="submit" href="menus.php">See More</a>
                </div>
            </div>
        </div>

    </div>
</section>


<!-- sunday special -->
<!-- <section class="sunday">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-11">
                <h5 class="main-title mb-5">Sunday Special Categories</h5>
            </div>
        </div>
        <div class="row">

            <div class="col-md-12">
                <div class="carousel-wrap">
                    <div id="carousels" class="owl-carousel">
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/special.jpg" class="img-fluid  shadow-lg">
                            <h3 class="text-center py-3">Bean Salad</h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section> -->


<!-- selctions -->
<!-- <section class="py-0 bg-select">
   
    <div class="container">
        <div class="row flex-center">
            <div class="col-xxl-12 py-5 text-center">

                <h1 class="fw-bold mb-4 text-white fs-1">Get Quotes To Book Your Meal</h1>
                <p>
                    <strong>Rate Per Tiffin & Timing :</strong> Breakfast, lunch, Dinner, All & Any Two etc..
                </p>
                <a class="btn banner-btn1" href="tiffin_order.php">Book Your Tiffin<svg class="svg-inline--fa fa-chevron-right fa-w-10 ms-2" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                        <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z">
                        </path>
                    </svg>
                </a>
            </div>
        </div>
    </div>
</section> -->
<!-- feature -->
<section class="feature pt-5 pb-1">
    <div class="container">
        <div class="row ">
            <div class="col-lg-5">
                <div class="section-header">
                    <h5 class="main-titles">Why Choose Us</h5>
                </div>
                <div class="feature-text">
                    <div class="feature-img">
                        <div class="row">
                            <div class="col-6">
                                <img src="assets/img/gallery/f1.jpeg" alt="Image" class="img-fluid">
                            </div>
                            <div class="col-6">
                                <img src="assets/img/gallery/f2.jpeg" alt="Image">
                            </div>
                            <div class="col-6">
                                <img src="assets/img/gallery/f3.jpeg" alt="Image">
                            </div>
                            <div class="col-6">
                                <img src="assets/img/gallery/f4.jpeg" alt="Image">
                            </div>
                        </div>
                    </div>
                    <p>We wish everyone a Healthy Life. Eat Healthy Home Food and Stay Fit.</p>
                    <a class="btn custom-btn" href="tiffin_order.php">Order Your Food </a>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="row">
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c1.png" alt=""></span>
                            <h3>Home Made Food</h3>
                            <p>
                            We provide homemade food in best quality because we care about our costomers health.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c2.png" alt=""></span>
                            <h3>Natural ingredients</h3>
                            <p>
                            We use natural ingredients at home, like grind and powder all seasonings and curries, so it gives the best flavor, taste, and smell.Best quality products
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c3.png" alt=""></span>
                            <h3>Best quality products</h3>
                            <p>
                                Lorem ipsum dolor sit amet elit. Phasel nec preti mi. Curabit facilis ornare velit non vulput metus tortor
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c4.png" alt=""></span>
                            <h3>Fresh vegetables </h3>
                            <p>
                            Food is freshly prepared by home chefs when they get an order. All the vegetables used are Fresh and Top quality to ensure food served is Healthy.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c5.png" alt=""></span>
                            <h3>Home Delivery</h3>
                            <p>
                            We provide home delivery and All the Delivery Riders are supervised daily for their temperature readings and conformity to Wearing a Mask, Hygiene and social distancing norms.
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-6">
                        <div class="feature-item">
                            <span><img src="assets/img/gallery/c6.png" alt=""></span>
                            <h3>Healthy &amp; Low fat</h3>
                            <p>
                            You don't have to compromise on taste if you choose health.  Make your way to Mishra Ji Ki Rasoi & enjoy a pocket-friendly, Healthy & Low-fat delicious meal! We got you covered! 
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>


<!-- testimonials -->
<section class="testimonial-section d-flex align-items-center">
    <div class="container">
        <div class="row">

            <div class="col-md-12 col-12">
                <div class="titles-test text-center">
                    <h5 class="main-title">What other say for us</h5>
                </div>
            </div>
        </div>
        <div class="row align-items-center">
            <div class="col-md-8 offset-md-2 col-12">
                <div id="myCarousel" class="carousel slide" data-bs-interval="5000" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item testi-item active">
                            <img src="assets/img/gallery/q.png" alt="" class="mb-2">
                            <p> " Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nobis ratione, harum doloremque aspernatur aliquid quaerat dolores voluptates recusandae qui repellat illum, amet ipsa debitis fugiat commodi nemo suscipit ad "</p>
                            <h3>john doe 1 - <span>web developer</span></h3>
                            <!-- <div class="stars mb-3">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div> -->
                        </div>
                        <div class="carousel-item testi-item">
                        <img src="assets/img/gallery/q.png" alt="" class="mb-2">
                            <p>" Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nobis ratione, harum doloremque aspernatur aliquid quaerat dolores voluptates recusandae qui repellat illum, amet ipsa debitis fugiat commodi nemo suscipit ad "</p>
                            <h3>john doe 2 - <span>web developer</span></h3>
                            <!-- <div class="stars mb-3">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div> -->
                        </div>
                        <div class="carousel-item testi-item">
                        <img src="assets/img/gallery/q.png" alt="" class="mb-2">
                            <p>" Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nobis ratione, harum doloremque aspernatur aliquid quaerat dolores voluptates recusandae qui repellat illum, amet ipsa debitis fugiat commodi nemo suscipit ad "</p>
                            <h3>john doe 3 - <span>web developer</span></h3>
                            <!-- <div class="stars mb-3">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                            </div> -->
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
                        <i class='fa fa-caret-left'></i>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
                        <i class='fa fa-caret-right'></i>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- offers -->
<section class="offers pt-3">
    <div class="container-fluid">
        <div class="row">

            <div class="col-md-12">
                <div class="owl-slider">
                    <div id="carousel" class="owl-carousel">
                        <div class="item">
                            <img src="assets/img/gallery/o1.jpg" alt="1000X1000">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o2.png" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o2.png" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o2.png" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o2.png" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o1.jpg" alt="">
                        </div>
                        <div class="item">
                            <img src="assets/img/gallery/o2.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="py-0 bg-holders">
    <!--/.bg-holder-->
    <div class="container">
        <div class="row flex-center">
            <div class="col-xxl-12 py-5 text-center">
                <h1 class="fw-bold mb-4 text-white fs-1">Are you ready to order <br>with the best deals? </h1>
                <a class="btn banner-btn1" href="party_order.php">ORDER FOR PARTY<svg class="svg-inline--fa fa-chevron-right fa-w-10 ms-2" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                        <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z">
                        </path>
                    </svg><!-- <i class="fas fa-chevron-right ms-2"></i> Font Awesome fontawesome.com --></a>
            </div>
        </div>
    </div>
</section>