<?php
include("header.php");
include("menu.php");
?>
<section class="breadcrumb overflow-hidden  bg-banner1 pt-5 pb-3" id="home">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="breadcrumb_iner text-center">
                    <div class="breadcrumb_iner_item">
                        <p>Home. About</p>
                        <h2>About us</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="welcome-area section-padding2 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6 align-self-center">
                <div class="welcome-img">
                    <img src="assets/img/gallery/about-home.png" class="img-fluid" alt="">
                </div>
            </div>
            <div class="col-md-6 align-self-center">
                <div class="welcome-text mt-md-0">
                    <h5 class="main-titles">Welcome to Mishra Ji Ki Rasoi</h5>
                    <p class="pt-3">We are reviving the culture of homemade food by offering a variety of traditional dishes to the people. Mishra Ji Ki Rasoi is enabling localized home food experiences by providing a delicious variety of authentic dishes cooked by talented home chefs. The home chef has learned the art of cooking through his unwavering passion and trained by his mother and grandmother to infuse love into the food. Mishra Ji Ki Rasoi is very selective and responsible in selecting Home Chefs. As a Company Policy, our Chef Enrollment team visits every aspiring Home chef to check for Kitchen hygiene and cleanliness, Food Quality and Packaging standards. Our Team of Food Tasting Experts Upholds our unwavering Customer Promise to serve Delicious and Healthy Food. </p>
                    <p>We are obsessed about Food Quality and as a policy every we call up every Customer to seek their Feedback on Food Delivered. As a practice, Our Home Chefs call up all customers to seek their taste preferences before cooking the Food.</p>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="pt-5">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card card-span mb-3 shadow-lg">
                    <div class="card-body py-0">
                        <div class="row justify-content-center">
                            <div class="col-md-5 col-xl-7 col-xxl-8 g-0 order-0 order-md-1">
                                <img class="img-fluid w-100 fit-cover h-100 rounded-top rounded-md-end rounded-md-top-0" src="assets/img/gallery/Lunch-box.jpg" alt="...">
                        </div>
                            <div class="col-md-7 col-xl-5 col-xxl-4 p-4 p-lg-5">
                                <h1 class="card-title mt-xl-5 mb-4">Wanna eat   <span class="text-warning"> home made food?</span></h1>
                                <p>Celebrate Home Food Every day and Explore the Food Culture of India. We feel Humbled that we are enabling Homemakers to contribute towards Nation Building and overjoyed with our Purpose.</p>
                                <div class="d-grid bottom-0"><a class="btn custom-btn mt-xl-6" href="#!">PROCEED TO ORDER<svg class="svg-inline--fa fa-chevron-right fa-w-10 ms-2" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" data-fa-i2svg="">
                                            <path fill="currentColor" d="M285.476 272.971L91.132 467.314c-9.373 9.373-24.569 9.373-33.941 0l-22.667-22.667c-9.357-9.357-9.375-24.522-.04-33.901L188.505 256 34.484 101.255c-9.335-9.379-9.317-24.544.04-33.901l22.667-22.667c9.373-9.373 24.569-9.373 33.941 0L285.475 239.03c9.373 9.372 9.373 24.568.001 33.941z"></path>
                                        </svg><!-- <i class="fas fa-chevron-right ms-2"></i> Font Awesome fontawesome.com --></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- end of .container-->
</section>
<?php
include("footer.php");
?>